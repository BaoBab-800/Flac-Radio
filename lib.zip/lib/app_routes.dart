import 'package:flutter/material.dart';
import 'package:musicplayer/Widgets/Pages/SettingsPage/settings_page_builder.dart';
/*
class AppRoutes {
  // Имена маршрутов
  static const settings = '/settings';

  // Словарь маршрутов для MaterialApp
  static Map<String, WidgetBuilder> routes = {
    settings: (context) => const SettingsPage(),
  };
}
 */